INSERT INTO Entity
(
	Id,
	Column1,
	Column2
)
VALUES
(
	1,
	'-- some text',
	'some text'
);