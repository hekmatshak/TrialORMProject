CREATE TABLE Entity1
(
	Id INTEGER AUTOINCREMENT PRIMARY KEY NOT NULL, /* block comment ; with semicolon */
	Column1 INTEGER
)
